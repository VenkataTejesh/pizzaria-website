import { Component } from '@angular/core';

@Component({
  selector: 'app-offers',
  standalone: true,
  imports: [],
  templateUrl: './offers.html',
  styleUrl: './offers.scss'
})
export class Offers {

}
